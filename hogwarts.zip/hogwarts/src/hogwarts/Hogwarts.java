/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hogwarts;
import classes.*;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author venum
 */
public class Hogwarts {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Auxiliar auxiliar = new Auxiliar();
        Dragones dragones = new Dragones();
        Hipogrifos hipogrifos = new Hipogrifos();
        Thestrals thestrals = new Thestrals();
        Nifflers nifflers = new Nifflers();
        Bowtruckles bowtruckles = new Bowtruckles();
        
        Scanner scanner = new Scanner(System.in);
        ArrayList<Criaturas> criaturas = new ArrayList<>();
        
         
        Dragones dragon1 = new Dragones(6, "DRAG01", true);
        Dragones dragon2 = new Dragones(4, "DRAG02", true);
        Hipogrifos hipogrifo1 = new Hipogrifos("alegre", 5, "HIP01", false);
        Hipogrifos hipogrifo2 = new Hipogrifos("enojado", 4, "HIP02", true);
        Thestrals thestral1 = new Thestrals(true, "THES01", true);
        Bowtruckles bowtruckles1 = new Bowtruckles(4, "BOW01", true);
         
        int opcion = 0;
        while(opcion != 5){
            System.out.println(" ");
            System.out.println("Bienvenido al registro magico de criaturas de hogwarts");
            System.out.println("------------------------------------------------------");
            System.out.println("- Seleccione una opcion -");
            System.out.println("");
            System.out.println("[1] Agregar criaturas");
            System.out.println("[2] Listar criaturas");
            System.out.println("[3] Cantidad total de criaturas bajo cuidado");
            System.out.println("[4] Mostrar costo total");
            System.out.println("[5] Salir");
            System.out.println("");
        
        opcion=scanner.nextInt();
        switch (opcion) {
            case 1:
                auxiliar.agregarCriatura(dragon1);
                auxiliar.agregarCriatura(dragon2);
                auxiliar.agregarCriatura(hipogrifo1);
                auxiliar.agregarCriatura(hipogrifo2);
                auxiliar.agregarCriatura(thestral1);
                auxiliar.agregarCriatura(bowtruckles1);
                
                System.out.println("Criaturas agregadas correctamente");
                break;
            case 2:
                auxiliar.listarCriaturas();
                break;
            case 3:
               auxiliar.contarCriaturas();
               break;
            case 4:
                System.out.println("Dragones: "+ dragones.costo_final(4));
                System.out.println("Hipogrifos :"+ hipogrifos.costo_final(3));
                System.out.println("Thestrals: "+ thestrals.costo_final(2));
                System.out.println("Nifflers: "+ nifflers.costo_final(5));
                System.out.println("Bowtruckles: "+ bowtruckles.costo_final(3));
                break;
            case 5:
                System.out.println("Saliendo...");
                break;
            }
        }
    }
}
