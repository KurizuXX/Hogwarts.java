/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author venum
 */
public class Thestrals extends Criaturas implements Costo_Magico{
    public boolean metodo_Especial;

    public Thestrals() {
    }

    public Thestrals(boolean metodo_Especial) {
        this.metodo_Especial = metodo_Especial;
    }

    public Thestrals(boolean metodo_Especial, String codigo_Unico, boolean requiere_Sup_Nocturna) {
        super(codigo_Unico, requiere_Sup_Nocturna);
        this.metodo_Especial = metodo_Especial;
    }

    public boolean isMetodo_Especial() {
        return metodo_Especial;
    }

    public void setMetodo_Especial(boolean metodo_Especial) {
        this.metodo_Especial = metodo_Especial;
    }

    public String getCodigo_Unico() {
        return codigo_Unico;
    }

    public void setCodigo_Unico(String codigo_Unico) {
        this.codigo_Unico = codigo_Unico;
    }

    public boolean isRequiere_Sup_Nocturna() {
        return requiere_Sup_Nocturna;
    }

    public void setRequiere_Sup_Nocturna(boolean requiere_Sup_Nocturna) {
        this.requiere_Sup_Nocturna = requiere_Sup_Nocturna;
    }

    @Override
    public String toString() {
        return "Thestrals{" + "metodo_Especial=" + metodo_Especial + '}';
    }

    @Override
    public void mostrar_Datos() {
        System.out.println("Codigo Unico: "+ getCodigo_Unico()+ 
                "Requiere supervision nocturna: "+isRequiere_Sup_Nocturna()+
                "Posee metodo especial para ver al Thestral: "+ isMetodo_Especial());
    }

    @Override
    public double costo_final(int dias) {
        double costo = VALOR_DIA_ALOJAMIENTO * dias;
        if(metodo_Especial == true){
            costo *= 1.08;
        }
        return costo;
    }
    

}
