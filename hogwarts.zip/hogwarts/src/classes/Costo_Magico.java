/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package classes;

/**
 *
 * @author venum
 */
public interface Costo_Magico {
    
    public double VALOR_DIA_ALOJAMIENTO = 250;
    double costo_final(int dias);
    
}
