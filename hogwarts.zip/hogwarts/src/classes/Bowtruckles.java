/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author venum
 */
public class Bowtruckles extends Criaturas implements Costo_Magico{
    
    public int cantidad_Arboles_Reparados;

    public Bowtruckles() {
    }

    public Bowtruckles(int cantidad_Arboles_Reparados) {
        this.cantidad_Arboles_Reparados = cantidad_Arboles_Reparados;
    }

    public Bowtruckles(int cantidad_Arboles_Reparados, String codigo_Unico, boolean requiere_Sup_Nocturna) {
        super(codigo_Unico, requiere_Sup_Nocturna);
        this.cantidad_Arboles_Reparados = cantidad_Arboles_Reparados;
    }

    public int getCantidad_Arboles_Reparados() {
        return cantidad_Arboles_Reparados;
    }

    public void setCantidad_Arboles_Reparados(int cantidad_Arboles_Reparados) {
        this.cantidad_Arboles_Reparados = cantidad_Arboles_Reparados;
    }

    public String getCodigo_Unico() {
        return codigo_Unico;
    }

    public void setCodigo_Unico(String codigo_Unico) {
        this.codigo_Unico = codigo_Unico;
    }

    public boolean isRequiere_Sup_Nocturna() {
        return requiere_Sup_Nocturna;
    }

    public void setRequiere_Sup_Nocturna(boolean requiere_Sup_Nocturna) {
        this.requiere_Sup_Nocturna = requiere_Sup_Nocturna;
    }

    @Override
    public String toString() {
        return "Bowtruckles{" + "cantidad_Arboles_Reparados=" + cantidad_Arboles_Reparados + '}';
    }

    @Override
    public void mostrar_Datos() {
        System.out.println("Codigo unico: "+getCodigo_Unico()+
                "Requiere supervision: "+isRequiere_Sup_Nocturna()+
                "Cantidad de arboles reparados: "+getCantidad_Arboles_Reparados());
    }

    @Override
    public double costo_final(int dias) {
        double costo = VALOR_DIA_ALOJAMIENTO*dias;
        if(cantidad_Arboles_Reparados > 3){
            costo -= costo*0.05;
        }
        return costo;
    }
    
    
    
   
}
