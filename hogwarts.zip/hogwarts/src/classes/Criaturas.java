/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author venum
 */
public abstract class Criaturas {
    
    public String codigo_Unico;
    public boolean requiere_Sup_Nocturna;

    public Criaturas() {
    }

    public Criaturas(String codigo_Unico, boolean requiere_Sup_Nocturna) {
        this.codigo_Unico = codigo_Unico;
        this.requiere_Sup_Nocturna = requiere_Sup_Nocturna;
    }

    public String getCodigo_Unico() {
        return codigo_Unico;
    }

    public void setCodigo_Unico(String codigo_Unico) {
        this.codigo_Unico = codigo_Unico;
    }

    public boolean isRequiere_Sup_Nocturna() {
        return requiere_Sup_Nocturna;
    }

    public void setRequiere_Sup_Nocturna(boolean requiere_Sup_Nocturna) {
        this.requiere_Sup_Nocturna = requiere_Sup_Nocturna;
    }

    @Override
    public String toString() {
        return "Criaturas{" + "codigo_Unico=" + codigo_Unico + ", requiere_Sup_Nocturna=" + requiere_Sup_Nocturna + '}';
    }
    
    public abstract void mostrar_Datos();
    
}
