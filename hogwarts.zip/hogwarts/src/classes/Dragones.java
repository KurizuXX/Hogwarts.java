/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author venum
 */
public class Dragones extends Criaturas implements Costo_Magico{
    public int veces_Escupe_Fuego;

    public Dragones() {
    }

    public Dragones(int veces_Escupe_Fuego) {
        this.veces_Escupe_Fuego = veces_Escupe_Fuego;
    }

    public Dragones(int veces_Escupe_Fuego, String codigo_Unico, boolean requiere_Sup_Nocturna) {
        super(codigo_Unico, requiere_Sup_Nocturna);
        this.veces_Escupe_Fuego = veces_Escupe_Fuego;
    }

    public int getVeces_Escupe_Fuego() {
        return veces_Escupe_Fuego;
    }

    public void setVeces_Escupe_Fuego(int veces_Escupe_Fuego) {
        this.veces_Escupe_Fuego = veces_Escupe_Fuego;
    }

    public String getCodigo_Unico() {
        return codigo_Unico;
    }

    public void setCodigo_Unico(String codigo_Unico) {
        this.codigo_Unico = codigo_Unico;
    }

    public boolean isRequiere_Sup_Nocturna() {
        return requiere_Sup_Nocturna;
    }

    public void setRequiere_Sup_Nocturna(boolean requiere_Sup_Nocturna) {
        this.requiere_Sup_Nocturna = requiere_Sup_Nocturna;
    }

    @Override
    public String toString() {
        return "Dragones{" + "veces_Escupe_Fuego=" + veces_Escupe_Fuego + '}';
    }

    @Override
    public void mostrar_Datos() {
        System.out.println("Codigo Magico: "+getCodigo_Unico()+
                "Requiere supervision nocturna: "+isRequiere_Sup_Nocturna()+ 
                "Veces que escupio fuego en el dia: "+ getVeces_Escupe_Fuego());
    }

    @Override
    public double costo_final(int dias) {
        double costo = VALOR_DIA_ALOJAMIENTO * dias;
        if(veces_Escupe_Fuego > 5){
            costo *= 1.15;
        }
        return costo;
    }
    
    
}
