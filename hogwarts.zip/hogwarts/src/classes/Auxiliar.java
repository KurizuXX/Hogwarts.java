/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 *
 * @author venum
 */
public class Auxiliar {
    //crear arreglo
    private ArrayList<Criaturas> criaturasRegistradas;
    
    public Auxiliar(){
        criaturasRegistradas = new ArrayList<>();
    }
    //agregar criatura y verificar que ya existe
    public boolean agregarCriatura(Criaturas criaturas){
        for(Criaturas i: criaturasRegistradas){
            if(i.getCodigo_Unico().equals(criaturas.getCodigo_Unico())){
                System.out.println("Codigo unico ya existe.");
               return false;
            }
        }
        criaturasRegistradas.add(criaturas);
        return true;
    }
    //listar criaturas registradas
    public void listarCriaturas(){
        for(Criaturas criatura: criaturasRegistradas){
            System.out.println(criatura);
        }
    }
    //contar el total de criaturas
    public int contarCriaturas(){
        return criaturasRegistradas.size();
    }
}
